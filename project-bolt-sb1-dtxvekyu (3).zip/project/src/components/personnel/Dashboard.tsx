import React, { useMemo } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getCheckInOuts, getOvertimeRequests, getLeaveRequests, getFactoryById } from '../../utils/localStorage';
import { isToday, formatDateTime } from '../../utils/dateUtils';
import { UserCircle, Clock, CheckCircle, XCircle } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  
  const dashboardData = useMemo(() => {
    if (!currentUser) return null;
    
    const userCheckInOuts = getCheckInOuts().filter(
      record => record.userId === currentUser.id
    );
    
    const userOvertimeRequests = getOvertimeRequests().filter(
      request => request.userId === currentUser.id
    );
    
    const userLeaveRequests = getLeaveRequests().filter(
      request => request.userId === currentUser.id
    );
    
    const todayCheckIns = userCheckInOuts.filter(
      record => isToday(record.timestamp) && record.type === 'check-in'
    );
    
    const todayCheckOuts = userCheckInOuts.filter(
      record => isToday(record.timestamp) && record.type === 'check-out'
    );
    
    const pendingOvertimeRequests = userOvertimeRequests.filter(
      request => request.status === 'pending'
    );
    
    const pendingLeaveRequests = userLeaveRequests.filter(
      request => request.status === 'pending'
    );
    
    const recentActivities = [...userCheckInOuts, ...userOvertimeRequests, ...userLeaveRequests]
      .sort((a, b) => {
        const dateA = 'timestamp' in a ? new Date(a.timestamp) : 
                     'date' in a ? new Date(a.date) : 
                     new Date(a.startDate);
        const dateB = 'timestamp' in b ? new Date(b.timestamp) : 
                     'date' in b ? new Date(b.date) : 
                     new Date(b.startDate);
        return dateB.getTime() - dateA.getTime();
      })
      .slice(0, 5);
      
    return {
      hasCheckedInToday: todayCheckIns.length > 0,
      hasCheckedOutToday: todayCheckOuts.length > 0,
      lastCheckIn: todayCheckIns.length > 0 ? todayCheckIns[todayCheckIns.length - 1] : null,
      lastCheckOut: todayCheckOuts.length > 0 ? todayCheckOuts[todayCheckOuts.length - 1] : null,
      pendingOvertimeRequestsCount: pendingOvertimeRequests.length,
      pendingLeaveRequestsCount: pendingLeaveRequests.length,
      recentActivities
    };
  }, [currentUser]);
  
  if (!currentUser || !dashboardData) {
    return <div>Yükleniyor...</div>;
  }
  
  const getActivityDetails = (activity: any) => {
    if ('timestamp' in activity) {
      const factory = activity.factoryId ? getFactoryById(activity.factoryId) : null;
      return {
        title: `${activity.type === 'check-in' ? 'Giriş' : 'Çıkış'} kaydı`,
        time: formatDateTime(activity.timestamp),
        description: factory ? `${factory.name} fabrikası` : '',
        icon: <Clock size={18} className="text-blue-500" />
      };
    } else if ('date' in activity) {
      return {
        title: `Fazla mesai talebi`,
        time: formatDateTime(activity.date),
        description: `${activity.startTime} - ${activity.endTime}`,
        status: activity.status,
        icon: <Clock size={18} className="text-yellow-500" />
      };
    } else {
      return {
        title: `İzin talebi`,
        time: `${formatDateTime(activity.startDate)} - ${formatDateTime(activity.endDate)}`,
        description: activity.type === 'annual' ? 'Yıllık izin' : 
                     activity.type === 'sick' ? 'Hastalık izni' : 
                     activity.type === 'unpaid' ? 'Ücretsiz izin' : 'Diğer',
        status: activity.status,
        icon: <Clock size={18} className="text-purple-500" />
      };
    }
  };
  
  return (
    <div>
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex items-center">
          <div className="p-4 rounded-full bg-blue-100 mr-4">
            <UserCircle size={32} className="text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Hoş geldin, {currentUser.name}</h1>
            <p className="text-gray-600">Günlük durumunuzu ve aktivitelerinizi buradan takip edebilirsiniz.</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Today's Status */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Bugünkü Durum</h2>
          
          <div className="space-y-4">
            <div className="flex items-center">
              {dashboardData.hasCheckedInToday ? (
                <CheckCircle size={20} className="text-green-500 mr-2" />
              ) : (
                <XCircle size={20} className="text-red-500 mr-2" />
              )}
              <span className="text-gray-700">
                {dashboardData.hasCheckedInToday
                  ? `Giriş yapıldı (${formatDateTime(dashboardData.lastCheckIn!.timestamp)})`
                  : 'Henüz giriş yapılmadı'}
              </span>
            </div>
            
            <div className="flex items-center">
              {dashboardData.hasCheckedOutToday ? (
                <CheckCircle size={20} className="text-green-500 mr-2" />
              ) : (
                <XCircle size={20} className="text-red-500 mr-2" />
              )}
              <span className="text-gray-700">
                {dashboardData.hasCheckedOutToday
                  ? `Çıkış yapıldı (${formatDateTime(dashboardData.lastCheckOut!.timestamp)})`
                  : 'Henüz çıkış yapılmadı'}
              </span>
            </div>
          </div>
        </div>
        
        {/* Pending Requests */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Bekleyen Talepler</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Fazla Mesai Talepleri:</span>
              <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">
                {dashboardData.pendingOvertimeRequestsCount}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-700">İzin Talepleri:</span>
              <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs">
                {dashboardData.pendingLeaveRequestsCount}
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Recent Activities */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Son Aktiviteler</h2>
        
        {dashboardData.recentActivities.length > 0 ? (
          <div className="divide-y">
            {dashboardData.recentActivities.map((activity, index) => {
              const details = getActivityDetails(activity);
              
              return (
                <div key={index} className="py-3 flex items-start">
                  <div className="mr-3 mt-1">{details.icon}</div>
                  <div>
                    <p className="text-gray-800 font-medium">{details.title}</p>
                    <p className="text-gray-500 text-sm">{details.time}</p>
                    {details.description && (
                      <p className="text-gray-600 text-sm mt-1">{details.description}</p>
                    )}
                    {'status' in details && (
                      <span
                        className={`inline-block mt-1 px-2 py-1 rounded-full text-xs ${
                          details.status === 'approved'
                            ? 'bg-green-100 text-green-800'
                            : details.status === 'rejected'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {details.status === 'approved'
                          ? 'Onaylandı'
                          : details.status === 'rejected'
                          ? 'Reddedildi'
                          : 'Beklemede'}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-4">Henüz aktivite yok</p>
        )}
      </div>
    </div>
  );
};

export default Dashboard;