import React, { useState, useEffect } from 'react';
import { getUsers, getFactories, addUser, updateUser, deleteUser } from '../../utils/localStorage';
import { User, Factory } from '../../types';
import { generateId } from '../../utils/dateUtils';
import { Plus, Edit, Trash2, X } from 'lucide-react';

const PersonnelManagement: React.FC = () => {
  const [personnel, setPersonnel] = useState<User[]>([]);
  const [factories, setFactories] = useState<Factory[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentPersonnel, setCurrentPersonnel] = useState<User | null>(null);
  
  // Form state
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [factoryId, setFactoryId] = useState('');
  
  useEffect(() => {
    loadPersonnel();
    setFactories(getFactories());
  }, []);
  
  const loadPersonnel = () => {
    const allUsers = getUsers();
    const personnelOnly = allUsers.filter(user => user.role === 'personnel');
    setPersonnel(personnelOnly);
  };
  
  const resetForm = () => {
    setName('');
    setPassword('');
    setFactoryId('');
    setCurrentPersonnel(null);
    setIsEditing(false);
  };
  
  const openAddModal = () => {
    resetForm();
    setShowModal(true);
  };
  
  const openEditModal = (personnel: User) => {
    setCurrentPersonnel(personnel);
    setName(personnel.name);
    setPassword(personnel.password);
    setFactoryId(personnel.factory || '');
    setIsEditing(true);
    setShowModal(true);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isEditing && currentPersonnel) {
      // Update existing personnel
      const updatedPersonnel = {
        ...currentPersonnel,
        name,
        password,
        factory: factoryId || undefined,
      };
      updateUser(updatedPersonnel);
    } else {
      // Add new personnel
      const newPersonnel: User = {
        id: generateId(),
        name,
        password,
        role: 'personnel',
        factory: factoryId || undefined,
      };
      addUser(newPersonnel);
    }
    
    loadPersonnel();
    setShowModal(false);
    resetForm();
  };
  
  const handleDelete = (id: string) => {
    if (window.confirm('Bu personeli silmek istediğinizden emin misiniz?')) {
      deleteUser(id);
      loadPersonnel();
    }
  };
  
  const getFactoryName = (factoryId: string | undefined) => {
    if (!factoryId) return 'Atanmamış';
    const factory = factories.find(f => f.id === factoryId);
    return factory ? factory.name : 'Bilinmeyen Fabrika';
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Personel Yönetimi</h1>
        <button
          onClick={openAddModal}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
        >
          <Plus size={18} className="mr-1" />
          Personel Ekle
        </button>
      </div>
      
      {/* Personnel List */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                İsim
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Fabrika
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Şifre
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                İşlemler
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {personnel.length > 0 ? (
              personnel.map((person) => (
                <tr key={person.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{person.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{getFactoryName(person.factory)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">••••••••</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => openEditModal(person)}
                      className="text-blue-600 hover:text-blue-900 mr-3"
                    >
                      <Edit size={18} />
                    </button>
                    <button
                      onClick={() => handleDelete(person.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                  Henüz personel kaydı bulunmamaktadır.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Add/Edit Personnel Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-gray-800">
                {isEditing ? 'Personel Düzenle' : 'Yeni Personel Ekle'}
              </h2>
              <button onClick={() => setShowModal(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  İsim
                </label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Şifre
                </label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="factory" className="block text-sm font-medium text-gray-700 mb-1">
                  Fabrika
                </label>
                <select
                  id="factory"
                  value={factoryId}
                  onChange={(e) => setFactoryId(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Seçiniz</option>
                  {factories.map(factory => (
                    <option key={factory.id} value={factory.id}>
                      {factory.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="mr-3 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
                >
                  {isEditing ? 'Güncelle' : 'Ekle'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PersonnelManagement;