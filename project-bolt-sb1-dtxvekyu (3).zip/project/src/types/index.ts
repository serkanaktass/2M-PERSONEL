export interface User {
  id: string;
  name: string;
  email?: string;
  password: string;
  role: 'admin' | 'personnel';
  factory?: string;
}

export interface Factory {
  id: string;
  name: string;
  address: string;
}

export interface CheckInOut {
  id: string;
  userId: string;
  factoryId: string;
  type: 'check-in' | 'check-out';
  timestamp: string;
  location: {
    latitude: number;
    longitude: number;
  };
}

export interface OvertimeRequest {
  id: string;
  userId: string;
  factoryId: string;
  date: string;
  startTime: string;
  endTime: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface LeaveRequest {
  id: string;
  userId: string;
  type: 'annual' | 'sick' | 'unpaid' | 'other';
  startDate: string;
  endDate: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  login: (nameOrEmail: string, password: string) => Promise<void>;
  logout: () => void;
}