import React, { useState } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { getFactories } from '../../utils/localStorage';
import { QrCode, Download } from 'lucide-react';

const QRCodeGenerator: React.FC = () => {
  const [selectedFactory, setSelectedFactory] = useState('');
  const factories = getFactories();

  const generateQRValue = (factoryId: string) => {
    return JSON.stringify({
      type: 'factory_checkin',
      factoryId,
      timestamp: new Date().toISOString()
    });
  };

  const downloadQRCode = () => {
    const canvas = document.getElementById('qr-code') as HTMLCanvasElement;
    if (canvas) {
      const url = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = url;
      link.download = `qr-code-${selectedFactory}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">QR Kod Yönetimi</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="mb-6">
          <label htmlFor="factory" className="block text-sm font-medium text-gray-700 mb-2">
            Fabrika Seçin
          </label>
          <select
            id="factory"
            value={selectedFactory}
            onChange={(e) => setSelectedFactory(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Fabrika seçin</option>
            {factories.map((factory) => (
              <option key={factory.id} value={factory.id}>
                {factory.name}
              </option>
            ))}
          </select>
        </div>

        {selectedFactory && (
          <div className="text-center">
            <div className="mb-4 p-4 inline-block bg-white rounded-lg shadow-lg">
              <QRCodeCanvas
                id="qr-code"
                value={generateQRValue(selectedFactory)}
                size={256}
                level="H"
                includeMargin={true}
              />
            </div>
            
            <div className="flex justify-center">
              <button
                onClick={downloadQRCode}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                <Download size={18} className="mr-2" />
                QR Kodu İndir
              </button>
            </div>
          </div>
        )}

        <div className="mt-6 p-4 bg-gray-50 rounded-md">
          <div className="flex items-start">
            <QrCode size={24} className="text-gray-500 mr-3 mt-1" />
            <div>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Nasıl Kullanılır?</h3>
              <ol className="list-decimal list-inside space-y-2 text-gray-600">
                <li>Fabrika için QR kod oluşturun</li>
                <li>QR kodu indirin ve fabrikada uygun bir yere asın</li>
                <li>Personel, giriş/çıkış yaparken bu QR kodu telefonuyla okutabilir</li>
                <li>Sistem otomatik olarak personelin konumunu ve zamanını kaydeder</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QRCodeGenerator;