import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';

// Auth components
import Login from './components/auth/Login';
import ProtectedRoute from './components/shared/ProtectedRoute';
import Layout from './components/shared/Layout';

// Admin components
import AdminDashboard from './components/admin/Dashboard';
import PersonnelManagement from './components/admin/PersonnelManagement';
import FactoryManagement from './components/admin/FactoryManagement';
import Reports from './components/admin/Reports';
import QRCodeGenerator from './components/admin/QRCodeGenerator';

// Personnel components
import PersonnelDashboard from './components/personnel/Dashboard';
import CheckInOut from './components/personnel/CheckInOut';
import QRScanner from './components/personnel/QRScanner';
import OvertimeRequest from './components/personnel/OvertimeRequest';
import LeaveRequest from './components/personnel/LeaveRequest';

const App: React.FC = () => {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          <Route path="/" element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }>
            {/* Admin Routes */}
            <Route path="" element={
              <ProtectedRoute>
                <Navigate to="/dashboard\" replace />
              </ProtectedRoute>
            } />
            
            <Route path="dashboard" element={
              <ProtectedRoute>
                <AdminDashboard />
              </ProtectedRoute>
            } />
            
            <Route path="personnel" element={
              <ProtectedRoute requiredRole="admin">
                <PersonnelManagement />
              </ProtectedRoute>
            } />
            
            <Route path="factories" element={
              <ProtectedRoute requiredRole="admin">
                <FactoryManagement />
              </ProtectedRoute>
            } />
            
            <Route path="reports" element={
              <ProtectedRoute requiredRole="admin">
                <Reports />
              </ProtectedRoute>
            } />

            <Route path="qr-generator" element={
              <ProtectedRoute requiredRole="admin">
                <QRCodeGenerator />
              </ProtectedRoute>
            } />
            
            {/* Personnel Routes */}
            <Route path="check-in-out" element={
              <ProtectedRoute requiredRole="personnel">
                <CheckInOut />
              </ProtectedRoute>
            } />

            <Route path="qr-scanner" element={
              <ProtectedRoute requiredRole="personnel">
                <QRScanner />
              </ProtectedRoute>
            } />
            
            <Route path="overtime" element={
              <ProtectedRoute requiredRole="personnel">
                <OvertimeRequest />
              </ProtectedRoute>
            } />
            
            <Route path="leave" element={
              <ProtectedRoute requiredRole="personnel">
                <LeaveRequest />
              </ProtectedRoute>
            } />
          </Route>
          
          <Route path="*" element={<Navigate to="/\" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;