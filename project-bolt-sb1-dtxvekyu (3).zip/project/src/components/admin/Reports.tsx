import React, { useState, useEffect, useMemo } from 'react';
import { getUsers, getFactories, getCheckInOuts, getOvertimeRequests, getLeaveRequests } from '../../utils/localStorage';
import { User, Factory, CheckInOut, OvertimeRequest, LeaveRequest } from '../../types';
import { formatDate, formatTime } from '../../utils/dateUtils';
import { FileText, Mail, MapPin } from 'lucide-react';

const Reports: React.FC = () => {
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [filterPersonnelId, setFilterPersonnelId] = useState<string>('');
  const [filterFactoryId, setFilterFactoryId] = useState<string>('');
  const [reportType, setReportType] = useState<'checkinout' | 'overtime' | 'leave'>('checkinout');
  const [emailSent, setEmailSent] = useState(false);
  
  const [users, setUsers] = useState<User[]>([]);
  const [factories, setFactories] = useState<Factory[]>([]);
  
  useEffect(() => {
    setUsers(getUsers().filter(user => user.role === 'personnel'));
    setFactories(getFactories());
  }, []);
  
  const filteredData = useMemo(() => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999); // End of the day
    
    if (reportType === 'checkinout') {
      const records = getCheckInOuts();
      return records.filter(record => {
        const recordDate = new Date(record.timestamp);
        const dateInRange = recordDate >= start && recordDate <= end;
        const matchesPersonnel = !filterPersonnelId || record.userId === filterPersonnelId;
        const matchesFactory = !filterFactoryId || record.factoryId === filterFactoryId;
        return dateInRange && matchesPersonnel && matchesFactory;
      });
    } else if (reportType === 'overtime') {
      const records = getOvertimeRequests();
      return records.filter(record => {
        const recordDate = new Date(record.date);
        const dateInRange = recordDate >= start && recordDate <= end;
        const matchesPersonnel = !filterPersonnelId || record.userId === filterPersonnelId;
        const matchesFactory = !filterFactoryId || record.factoryId === filterFactoryId;
        return dateInRange && matchesPersonnel && matchesFactory;
      });
    } else {
      const records = getLeaveRequests();
      return records.filter(record => {
        const recordDate = new Date(record.startDate);
        const dateInRange = recordDate >= start && recordDate <= end;
        const matchesPersonnel = !filterPersonnelId || record.userId === filterPersonnelId;
        return dateInRange && matchesPersonnel;
      });
    }
  }, [reportType, startDate, endDate, filterPersonnelId, filterFactoryId]);
  
  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Bilinmeyen Kullanıcı';
  };
  
  const getFactoryName = (factoryId: string) => {
    const factory = factories.find(f => f.id === factoryId);
    return factory ? factory.name : 'Bilinmeyen Fabrika';
  };
  
  const handleSendEmail = () => {
    // In a real application, this would send the report via email
    // For this demo, we'll just show a success message
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 3000);
  };
  
  const renderReportTable = () => {
    if (reportType === 'checkinout') {
      return (
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Personel
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Fabrika
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                İşlem
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tarih
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Saat
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Konum
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredData.length > 0 ? (
              (filteredData as CheckInOut[]).map((record, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {getUserName(record.userId)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {getFactoryName(record.factoryId)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        record.type === 'check-in'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {record.type === 'check-in' ? 'Giriş' : 'Çıkış'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(record.timestamp)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatTime(record.timestamp)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="flex items-center">
                      <MapPin size={16} className="text-gray-400 mr-1" />
                      <span>
                        {record.location.latitude.toFixed(6)}, {record.location.longitude.toFixed(6)}
                      </span>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                  Seçilen kriterlere uygun kayıt bulunamadı.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      );
    } else if (reportType === 'overtime') {
      return (
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Personel
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Fabrika
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tarih
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Başlangıç - Bitiş
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Açıklama
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Durum
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredData.length > 0 ? (
              (filteredData as OvertimeRequest[]).map((record, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {getUserName(record.userId)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {getFactoryName(record.factoryId)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(record.date)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {record.startTime} - {record.endTime}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                    {record.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        record.status === 'approved'
                          ? 'bg-green-100 text-green-800'
                          : record.status === 'rejected'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {record.status === 'approved'
                        ? 'Onaylandı'
                        : record.status === 'rejected'
                        ? 'Reddedildi'
                        : 'Beklemede'}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                  Seçilen kriterlere uygun kayıt bulunamadı.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      );
    } else {
      return (
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Personel
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                İzin Tipi
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Başlangıç
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Bitiş
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Açıklama
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Durum
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredData.length > 0 ? (
              (filteredData as LeaveRequest[]).map((record, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {getUserName(record.userId)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {record.type === 'annual'
                      ? 'Yıllık'
                      : record.type === 'sick'
                      ? 'Hastalık'
                      : record.type === 'unpaid'
                      ? 'Ücretsiz'
                      : 'Diğer'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(record.startDate)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(record.endDate)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                    {record.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        record.status === 'approved'
                          ? 'bg-green-100 text-green-800'
                          : record.status === 'rejected'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {record.status === 'approved'
                        ? 'Onaylandı'
                        : record.status === 'rejected'
                        ? 'Reddedildi'
                        : 'Beklemede'}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                  Seçilen kriterlere uygun kayıt bulunamadı.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      );
    }
  };
  
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Raporlar</h1>
      
      {/* Email success message */}
      {emailSent && (
        <div className="mb-4 p-3 bg-green-100 text-green-700 rounded-md flex items-center">
          <Mail size={18} className="mr-2" />
          Rapor e-posta olarak gönderildi.
        </div>
      )}
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label htmlFor="reportType" className="block text-sm font-medium text-gray-700 mb-1">
              Rapor Tipi
            </label>
            <select
              id="reportType"
              value={reportType}
              onChange={(e) => setReportType(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="checkinout">Giriş/Çıkış Kayıtları</option>
              <option value="overtime">Fazla Mesai Talepleri</option>
              <option value="leave">İzin Talepleri</option>
            </select>
          </div>
          
          <div>
            <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
              Başlangıç Tarihi
            </label>
            <input
              type="date"
              id="startDate"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">
              Bitiş Tarihi
            </label>
            <input
              type="date"
              id="endDate"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label htmlFor="personnel" className="block text-sm font-medium text-gray-700 mb-1">
              Personel
            </label>
            <select
              id="personnel"
              value={filterPersonnelId}
              onChange={(e) => setFilterPersonnelId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Tümü</option>
              {users.map(user => (
                <option key={user.id} value={user.id}>
                  {user.name}
                </option>
              ))}
            </select>
          </div>
          
          {reportType !== 'leave' && (
            <div>
              <label htmlFor="factory" className="block text-sm font-medium text-gray-700 mb-1">
                Fabrika
              </label>
              <select
                id="factory"
                value={filterFactoryId}
                onChange={(e) => setFilterFactoryId(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Tümü</option>
                {factories.map(factory => (
                  <option key={factory.id} value={factory.id}>
                    {factory.name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>
      
      {/* Report Actions */}
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800">
          {reportType === 'checkinout'
            ? 'Giriş/Çıkış Kayıtları'
            : reportType === 'overtime'
            ? 'Fazla Mesai Talepleri'
            : 'İzin Talepleri'}
        </h2>
        
        <div className="flex space-x-3">
          <button
            onClick={handleSendEmail}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center"
          >
            <Mail size={18} className="mr-1" />
            E-posta Gönder
          </button>
          <button
            onClick={() => console.log('Export to Excel')}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
          >
            <FileText size={18} className="mr-1" />
            Excel'e Aktar
          </button>
        </div>
      </div>
      
      {/* Report Table */}
      <div className="bg-white rounded-lg shadow overflow-x-auto">
        {renderReportTable()}
      </div>
    </div>
  );
};

export default Reports;