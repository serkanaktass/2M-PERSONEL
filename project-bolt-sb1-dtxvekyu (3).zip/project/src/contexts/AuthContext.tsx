import React, { createContext, useState, useEffect, useContext } from 'react';
import { User, AuthContextType } from '../types';
import {
  getCurrentUser,
  setCurrentUser,
  getUserByNameOrEmail,
} from '../utils/localStorage';

const defaultAuthContext: AuthContextType = {
  currentUser: null,
  loading: true,
  login: async () => {
    throw new Error('login function not implemented');
  },
  logout: () => {
    throw new Error('logout function not implemented');
  },
};

const AuthContext = createContext<AuthContextType>(defaultAuthContext);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const user = getCurrentUser();
    setUser(user);
    setLoading(false);
  }, []);

  const login = async (nameOrEmail: string, password: string): Promise<void> => {
    const user = getUserByNameOrEmail(nameOrEmail);
    
    if (!user || user.password !== password) {
      throw new Error('Invalid credentials');
    }

    setUser(user);
    setCurrentUser(user);
  };

  const logout = () => {
    setUser(null);
    setCurrentUser(null);
  };

  const value = {
    currentUser,
    loading,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};