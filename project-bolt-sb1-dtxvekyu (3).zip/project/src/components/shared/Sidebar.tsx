import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import {
  Home,
  Users,
  Building2,
  ClipboardList,
  Clock,
  Calendar,
  FileText,
  QrCode,
  Scan
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  const linkClass = "flex items-center p-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-md transition-colors";
  const activeLinkClass = "bg-blue-50 text-blue-600";

  return (
    <aside className="bg-white w-64 min-h-screen shadow-md py-6 px-4">
      <nav>
        <ul className="space-y-2">
          <li>
            <NavLink
              to="/"
              className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
            >
              <Home size={18} className="mr-3" />
              <span>Ana Sayfa</span>
            </NavLink>
          </li>

          {isAdmin ? (
            // Admin links
            <>
              <li>
                <NavLink
                  to="/personnel"
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
                >
                  <Users size={18} className="mr-3" />
                  <span>Personel Yönetimi</span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/factories"
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
                >
                  <Building2 size={18} className="mr-3" />
                  <span>Fabrika Yönetimi</span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/qr-generator"
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
                >
                  <QrCode size={18} className="mr-3" />
                  <span>QR Kod Yönetimi</span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/reports"
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
                >
                  <FileText size={18} className="mr-3" />
                  <span>Raporlar</span>
                </NavLink>
              </li>
            </>
          ) : (
            // Personnel links
            <>
              <li>
                <NavLink
                  to="/check-in-out"
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
                >
                  <Clock size={18} className="mr-3" />
                  <span>Giriş / Çıkış</span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/qr-scanner"
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
                >
                  <Scan size={18} className="mr-3" />
                  <span>QR ile Giriş</span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/overtime"
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
                >
                  <ClipboardList size={18} className="mr-3" />
                  <span>Fazla Mesai Talebi</span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/leave"
                  className={({ isActive }) => `${linkClass} ${isActive ? activeLinkClass : ''}`}
                >
                  <Calendar size={18} className="mr-3" />
                  <span>İzin Talebi</span>
                </NavLink>
              </li>
            </>
          )}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;