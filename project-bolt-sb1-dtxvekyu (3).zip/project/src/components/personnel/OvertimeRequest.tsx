import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getFactories, addOvertimeRequest, getOvertimeRequests } from '../../utils/localStorage';
import { generateId, formatDate } from '../../utils/dateUtils';
import { Factory, OvertimeRequest } from '../../types';
import { Clock, Calendar } from 'lucide-react';

const OvertimeRequestComponent: React.FC = () => {
  const { currentUser } = useAuth();
  const [factories, setFactories] = useState<Factory[]>([]);
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState<string>('17:00');
  const [endTime, setEndTime] = useState<string>('19:00');
  const [description, setDescription] = useState<string>('');
  const [factoryId, setFactoryId] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [userRequests, setUserRequests] = useState<OvertimeRequest[]>([]);
  
  useEffect(() => {
    setFactories(getFactories());
    
    // Set the factory if the user has one assigned
    if (currentUser?.factory) {
      setFactoryId(currentUser.factory);
    }
    
    loadUserRequests();
  }, [currentUser]);
  
  const loadUserRequests = () => {
    if (currentUser) {
      const requests = getOvertimeRequests().filter(
        request => request.userId === currentUser.id
      );
      setUserRequests(requests);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser || !factoryId) {
      return;
    }
    
    setSubmitting(true);
    
    const newRequest: OvertimeRequest = {
      id: generateId(),
      userId: currentUser.id,
      factoryId,
      date,
      startTime,
      endTime,
      description,
      status: 'pending',
    };
    
    addOvertimeRequest(newRequest);
    loadUserRequests();
    
    // Reset form
    setDate(new Date().toISOString().split('T')[0]);
    setStartTime('17:00');
    setEndTime('19:00');
    setDescription('');
    setSubmitting(false);
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">Onaylandı</span>;
      case 'rejected':
        return <span className="px-2 py-1 rounded-full text-xs bg-red-100 text-red-800">Reddedildi</span>;
      default:
        return <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">Beklemede</span>;
    }
  };
  
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Fazla Mesai Talebi</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Yeni Talep</h2>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="factory" className="block text-sm font-medium text-gray-700 mb-1">
                Fabrika
              </label>
              <select
                id="factory"
                value={factoryId}
                onChange={(e) => setFactoryId(e.target.value)}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Fabrika Seçiniz</option>
                {factories.map(factory => (
                  <option key={factory.id} value={factory.id}>
                    {factory.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="mb-4">
              <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">
                Tarih
              </label>
              <input
                type="date"
                id="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="startTime" className="block text-sm font-medium text-gray-700 mb-1">
                  Başlangıç Saati
                </label>
                <input
                  type="time"
                  id="startTime"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div>
                <label htmlFor="endTime" className="block text-sm font-medium text-gray-700 mb-1">
                  Bitiş Saati
                </label>
                <input
                  type="time"
                  id="endTime"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Açıklama
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              ></textarea>
            </div>
            
            <button
              type="submit"
              disabled={submitting}
              className="w-full flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              <Clock size={18} className="mr-1" />
              Talep Oluştur
            </button>
          </form>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Taleplerim</h2>
          
          {userRequests.length > 0 ? (
            <div className="divide-y">
              {userRequests.map((request, index) => {
                const factory = factories.find(f => f.id === request.factoryId);
                
                return (
                  <div key={index} className="py-3 flex items-start">
                    <div className="mr-3 mt-1">
                      <Calendar size={18} className="text-blue-500" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <p className="text-gray-800 font-medium">
                          {factory ? factory.name : 'Bilinmeyen Fabrika'}
                        </p>
                        {getStatusBadge(request.status)}
                      </div>
                      <p className="text-gray-500 text-sm">
                        {formatDate(request.date)} ({request.startTime} - {request.endTime})
                      </p>
                      {request.description && (
                        <p className="text-gray-600 text-sm mt-1">{request.description}</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-4">Henüz fazla mesai talebiniz bulunmamaktadır.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default OvertimeRequestComponent;