import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { addLeaveRequest, getLeaveRequests } from '../../utils/localStorage';
import { generateId, formatDate } from '../../utils/dateUtils';
import { LeaveRequest } from '../../types';
import { Calendar } from 'lucide-react';

const LeaveRequestComponent: React.FC = () => {
  const { currentUser } = useAuth();
  const [type, setType] = useState<'annual' | 'sick' | 'unpaid' | 'other'>('annual');
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [userRequests, setUserRequests] = useState<LeaveRequest[]>([]);
  
  useEffect(() => {
    loadUserRequests();
  }, [currentUser]);
  
  const loadUserRequests = () => {
    if (currentUser) {
      const requests = getLeaveRequests().filter(
        request => request.userId === currentUser.id
      );
      setUserRequests(requests);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      return;
    }
    
    setSubmitting(true);
    
    const newRequest: LeaveRequest = {
      id: generateId(),
      userId: currentUser.id,
      type,
      startDate,
      endDate,
      description,
      status: 'pending',
    };
    
    addLeaveRequest(newRequest);
    loadUserRequests();
    
    // Reset form
    setType('annual');
    setStartDate(new Date().toISOString().split('T')[0]);
    setEndDate(new Date().toISOString().split('T')[0]);
    setDescription('');
    setSubmitting(false);
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">Onaylandı</span>;
      case 'rejected':
        return <span className="px-2 py-1 rounded-full text-xs bg-red-100 text-red-800">Reddedildi</span>;
      default:
        return <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">Beklemede</span>;
    }
  };
  
  const getTypeText = (type: string) => {
    switch (type) {
      case 'annual':
        return 'Yıllık İzin';
      case 'sick':
        return 'Hastalık İzni';
      case 'unpaid':
        return 'Ücretsiz İzin';
      default:
        return 'Diğer';
    }
  };
  
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">İzin Talebi</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Yeni İzin Talebi</h2>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-1">
                İzin Türü
              </label>
              <select
                id="type"
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="annual">Yıllık İzin</option>
                <option value="sick">Hastalık İzni</option>
                <option value="unpaid">Ücretsiz İzin</option>
                <option value="other">Diğer</option>
              </select>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
                  Başlangıç Tarihi
                </label>
                <input
                  type="date"
                  id="startDate"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div>
                <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">
                  Bitiş Tarihi
                </label>
                <input
                  type="date"
                  id="endDate"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  required
                  min={startDate}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Açıklama
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              ></textarea>
            </div>
            
            <button
              type="submit"
              disabled={submitting}
              className="w-full flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              <Calendar size={18} className="mr-1" />
              Talep Oluştur
            </button>
          </form>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">İzin Taleplerim</h2>
          
          {userRequests.length > 0 ? (
            <div className="divide-y">
              {userRequests.map((request, index) => (
                <div key={index} className="py-3 flex items-start">
                  <div className="mr-3 mt-1">
                    <Calendar size={18} className="text-blue-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <p className="text-gray-800 font-medium">{getTypeText(request.type)}</p>
                      {getStatusBadge(request.status)}
                    </div>
                    <p className="text-gray-500 text-sm">
                      {formatDate(request.startDate)} - {formatDate(request.endDate)}
                    </p>
                    {request.description && (
                      <p className="text-gray-600 text-sm mt-1">{request.description}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-4">Henüz izin talebiniz bulunmamaktadır.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default LeaveRequestComponent;