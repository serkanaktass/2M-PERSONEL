import React, { useState, useEffect } from 'react';
import { BrowserQRCodeReader } from '@zxing/browser';
import { useAuth } from '../../contexts/AuthContext';
import { useGeolocation } from '../../hooks/useGeolocation';
import { addCheckInOut, getFactoryById } from '../../utils/localStorage';
import { generateId } from '../../utils/dateUtils';
import { QrCode, CheckCircle, XCircle } from 'lucide-react';

const QRScanner: React.FC = () => {
  const { currentUser } = useAuth();
  const { location } = useGeolocation();
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<{ success: boolean; message: string } | null>(null);
  const [codeReader, setCodeReader] = useState<BrowserQRCodeReader | null>(null);

  useEffect(() => {
    const reader = new BrowserQRCodeReader();
    setCodeReader(reader);

    return () => {
      if (codeReader) {
        codeReader.reset();
      }
    };
  }, []);

  const handleScan = async () => {
    if (!codeReader) return;

    try {
      setScanning(true);
      const videoInputDevices = await BrowserQRCodeReader.listVideoInputDevices();
      const selectedDeviceId = videoInputDevices[0].deviceId;

      const result = await codeReader.decodeFromVideoDevice(
        selectedDeviceId,
        'video-element',
        (result, error) => {
          if (result && currentUser && location) {
            try {
              const qrData = JSON.parse(result.getText());
              if (qrData.type === 'factory_checkin') {
                const factory = getFactoryById(qrData.factoryId);
                if (!factory) {
                  setScanResult({ success: false, message: 'Geçersiz fabrika QR kodu.' });
                  return;
                }

                const checkInOut = {
                  id: generateId(),
                  userId: currentUser.id,
                  factoryId: qrData.factoryId,
                  type: 'check-in',
                  timestamp: new Date().toISOString(),
                  location: {
                    latitude: location.latitude,
                    longitude: location.longitude,
                  },
                };

                addCheckInOut(checkInOut);
                setScanResult({ success: true, message: `${factory.name} fabrikasına giriş yapıldı.` });
                setScanning(false);
                codeReader.reset();
              }
            } catch (error) {
              setScanResult({ success: false, message: 'Geçersiz QR kod.' });
            }
          }
          if (error) {
            console.error(error);
          }
        }
      );

      if (!result) {
        setScanResult({ success: false, message: 'QR kod okunamadı.' });
      }
    } catch (error) {
      console.error(error);
      setScanResult({ success: false, message: 'Kamera erişiminde hata oluştu.' });
    }
  };

  const stopScanning = () => {
    if (codeReader) {
      codeReader.reset();
    }
    setScanning(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <QrCode size={24} className="text-blue-600 mr-3" />
        <h2 className="text-xl font-semibold text-gray-800">QR Kod ile Giriş/Çıkış</h2>
      </div>

      {!scanning && !scanResult && (
        <button
          onClick={handleScan}
          className="w-full py-3 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center"
        >
          <QrCode size={20} className="mr-2" />
          QR Kodu Tara
        </button>
      )}

      {scanning && (
        <div className="relative">
          <video
            id="video-element"
            className="w-full max-w-sm mx-auto rounded-lg"
          ></video>
          <button
            onClick={stopScanning}
            className="mt-4 w-full py-2 px-4 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
          >
            İptal
          </button>
        </div>
      )}

      {scanResult && (
        <div className={`mt-4 p-4 rounded-lg ${scanResult.success ? 'bg-green-50' : 'bg-red-50'}`}>
          <div className="flex items-center">
            {scanResult.success ? (
              <CheckCircle size={20} className="text-green-500 mr-2" />
            ) : (
              <XCircle size={20} className="text-red-500 mr-2" />
            )}
            <p className={scanResult.success ? 'text-green-700' : 'text-red-700'}>
              {scanResult.message}
            </p>
          </div>
          <button
            onClick={() => setScanResult(null)}
            className="mt-4 w-full py-2 px-4 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
          >
            Yeni Tarama
          </button>
        </div>
      )}
    </div>
  );
};

export default QRScanner;