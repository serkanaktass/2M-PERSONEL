import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useGeolocation } from '../../hooks/useGeolocation';
import { getFactories, addCheckInOut, getCheckInOuts } from '../../utils/localStorage';
import { generateId, isToday, formatDateTime } from '../../utils/dateUtils';
import { Factory, CheckInOut } from '../../types';
import { MapPin, LogIn, LogOut, Clock } from 'lucide-react';

const CheckInOutComponent: React.FC = () => {
  const { currentUser } = useAuth();
  const { location, loading: locationLoading, error: locationError } = useGeolocation();
  const [factories, setFactories] = useState<Factory[]>([]);
  const [selectedFactory, setSelectedFactory] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [todayRecords, setTodayRecords] = useState<CheckInOut[]>([]);
  const [type, setType] = useState<'check-in' | 'check-out'>('check-in');
  
  useEffect(() => {
    setFactories(getFactories());
    loadTodayRecords();
    
    // Set the factory if the user has one assigned
    if (currentUser?.factory) {
      setSelectedFactory(currentUser.factory);
    }
  }, [currentUser]);
  
  const loadTodayRecords = () => {
    if (currentUser) {
      const records = getCheckInOuts().filter(
        record => record.userId === currentUser.id && isToday(record.timestamp)
      );
      setTodayRecords(records);
      
      // Determine the next action type based on today's records
      const hasCheckIn = records.some(record => record.type === 'check-in');
      const hasCheckOut = records.some(record => record.type === 'check-out');
      
      if (hasCheckIn && !hasCheckOut) {
        setType('check-out');
      } else {
        setType('check-in');
      }
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser || !location || !selectedFactory) {
      return;
    }
    
    setSubmitting(true);
    
    const newRecord: CheckInOut = {
      id: generateId(),
      userId: currentUser.id,
      factoryId: selectedFactory,
      type,
      timestamp: new Date().toISOString(),
      location: {
        latitude: location.latitude,
        longitude: location.longitude,
      },
    };
    
    addCheckInOut(newRecord);
    loadTodayRecords();
    
    // Switch to the other type
    setType(type === 'check-in' ? 'check-out' : 'check-in');
    setSubmitting(false);
  };
  
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Giriş / Çıkış</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">
            {type === 'check-in' ? 'Giriş Yap' : 'Çıkış Yap'}
          </h2>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="factory" className="block text-sm font-medium text-gray-700 mb-1">
                Fabrika
              </label>
              <select
                id="factory"
                value={selectedFactory}
                onChange={(e) => setSelectedFactory(e.target.value)}
                required
                disabled={submitting || locationLoading}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100"
              >
                <option value="">Fabrika Seçiniz</option>
                {factories.map(factory => (
                  <option key={factory.id} value={factory.id}>
                    {factory.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="mb-6">
              <div className="p-3 bg-gray-50 rounded-md flex items-start">
                <MapPin size={18} className="text-gray-500 mt-0.5 mr-2 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Konum</p>
                  {locationLoading ? (
                    <p className="text-sm text-gray-500">Konum bilgisi alınıyor...</p>
                  ) : locationError ? (
                    <p className="text-sm text-red-500">{locationError}</p>
                  ) : location ? (
                    <p className="text-sm text-gray-500">
                      Enlem: {location.latitude.toFixed(6)}, Boylam: {location.longitude.toFixed(6)}
                    </p>
                  ) : (
                    <p className="text-sm text-red-500">Konum bilgisi alınamadı.</p>
                  )}
                </div>
              </div>
            </div>
            
            <button
              type="submit"
              disabled={submitting || locationLoading || !location || !selectedFactory}
              className={`w-full flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white ${
                type === 'check-in'
                  ? 'bg-green-600 hover:bg-green-700'
                  : 'bg-red-600 hover:bg-red-700'
              } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50`}
            >
              {type === 'check-in' ? (
                <>
                  <LogIn size={18} className="mr-1" />
                  Giriş Yap
                </>
              ) : (
                <>
                  <LogOut size={18} className="mr-1" />
                  Çıkış Yap
                </>
              )}
            </button>
          </form>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Bugünkü Kayıtlar</h2>
          
          {todayRecords.length > 0 ? (
            <div className="divide-y">
              {todayRecords.map((record, index) => {
                const factory = factories.find(f => f.id === record.factoryId);
                
                return (
                  <div key={index} className="py-3 flex items-start">
                    <div className="mr-3 mt-1">
                      <Clock size={18} className="text-blue-500" />
                    </div>
                    <div>
                      <div className="flex items-center">
                        <span
                          className={`px-2 py-1 rounded-full text-xs mr-2 ${
                            record.type === 'check-in'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {record.type === 'check-in' ? 'Giriş' : 'Çıkış'}
                        </span>
                        <p className="text-gray-800 font-medium">
                          {factory ? factory.name : 'Bilinmeyen Fabrika'}
                        </p>
                      </div>
                      <p className="text-gray-500 text-sm">{formatDateTime(record.timestamp)}</p>
                      <p className="text-gray-500 text-xs mt-1">
                        Konum: {record.location.latitude.toFixed(6)}, {record.location.longitude.toFixed(6)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-4">Bugün henüz giriş veya çıkış yapılmadı.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default CheckInOutComponent;