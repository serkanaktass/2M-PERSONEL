import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { User, LogOut } from 'lucide-react';

const Header: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <img 
            src="/logo.png" 
            alt="2M Personel" 
            className="h-10 mr-3" 
            onError={(e) => {
              // Fallback if logo image is not available
              (e.target as HTMLImageElement).src = 'https://via.placeholder.com/150x50?text=2M+Personel';
            }}
          />
          <h1 className="text-xl font-semibold text-gray-800">2M Personel</h1>
        </div>
        
        {currentUser && (
          <div className="flex items-center">
            <div className="mr-4 text-gray-600">
              <span className="font-medium">{currentUser.name}</span>
              <span className="text-sm ml-2 text-gray-500">
                {currentUser.role === 'admin' ? 'Admin' : 'Personel'}
              </span>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center text-gray-600 hover:text-blue-600 transition-colors"
            >
              <LogOut size={18} className="mr-1" />
              <span>Çıkış</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;