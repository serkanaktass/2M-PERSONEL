import React, { useMemo } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getUsers, getCheckInOuts, getOvertimeRequests, getLeaveRequests } from '../../utils/localStorage';
import { isToday, formatDateTime } from '../../utils/dateUtils';
import { Users, Clock, Calendar, AlertCircle } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  
  // Memoize data to avoid recalculating on every render
  const dashboardData = useMemo(() => {
    const users = getUsers();
    const checkInOuts = getCheckInOuts();
    const overtimeRequests = getOvertimeRequests();
    const leaveRequests = getLeaveRequests();

    const personnelCount = users.filter(user => user.role === 'personnel').length;
    const todayCheckIns = checkInOuts.filter(record => isToday(record.timestamp) && record.type === 'check-in');
    const pendingOvertimeRequests = overtimeRequests.filter(req => req.status === 'pending');
    const pendingLeaveRequests = leaveRequests.filter(req => req.status === 'pending');
    
    const todayActivities = [...checkInOuts, ...overtimeRequests, ...leaveRequests]
      .filter(item => {
        if ('timestamp' in item) return isToday(item.timestamp);
        if ('date' in item) return isToday(item.date);
        if ('startDate' in item) return isToday(item.startDate);
        return false;
      })
      .sort((a, b) => {
        const dateA = 'timestamp' in a ? new Date(a.timestamp) : 
                    'date' in a ? new Date(a.date) : 
                    new Date(a.startDate);
        const dateB = 'timestamp' in b ? new Date(b.timestamp) : 
                    'date' in b ? new Date(b.date) : 
                    new Date(b.startDate);
        return dateB.getTime() - dateA.getTime();
      })
      .slice(0, 5);
      
    return {
      personnelCount,
      todayCheckInsCount: todayCheckIns.length,
      pendingOvertimeRequestsCount: pendingOvertimeRequests.length,
      pendingLeaveRequestsCount: pendingLeaveRequests.length,
      todayActivities
    };
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Yönetici Paneli</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-blue-100 p-3 mr-4">
            <Users size={24} className="text-blue-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Toplam Personel</p>
            <p className="text-2xl font-bold">{dashboardData.personnelCount}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-green-100 p-3 mr-4">
            <Clock size={24} className="text-green-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Bugünkü Girişler</p>
            <p className="text-2xl font-bold">{dashboardData.todayCheckInsCount}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-yellow-100 p-3 mr-4">
            <Clock size={24} className="text-yellow-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Bekleyen Fazla Mesai</p>
            <p className="text-2xl font-bold">{dashboardData.pendingOvertimeRequestsCount}</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
          <div className="rounded-full bg-purple-100 p-3 mr-4">
            <Calendar size={24} className="text-purple-600" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Bekleyen İzin Talepleri</p>
            <p className="text-2xl font-bold">{dashboardData.pendingLeaveRequestsCount}</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Bugünkü Aktiviteler</h2>
        
        {dashboardData.todayActivities.length > 0 ? (
          <div className="divide-y">
            {dashboardData.todayActivities.map((activity, index) => {
              let title = '';
              let time = '';
              let icon = <AlertCircle size={18} className="text-gray-400" />;
              let description = '';
              
              if ('timestamp' in activity) {
                const user = getUsers().find(u => u.id === activity.userId);
                title = `${user?.name || 'Kullanıcı'} ${activity.type === 'check-in' ? 'giriş' : 'çıkış'} yaptı`;
                time = formatDateTime(activity.timestamp);
                icon = <Clock size={18} className="text-blue-500" />;
              } else if ('date' in activity) {
                const user = getUsers().find(u => u.id === activity.userId);
                title = `${user?.name || 'Kullanıcı'} fazla mesai talebinde bulundu`;
                time = formatDateTime(activity.date);
                description = activity.description;
                icon = <Clock size={18} className="text-yellow-500" />;
              } else if ('startDate' in activity) {
                const user = getUsers().find(u => u.id === activity.userId);
                title = `${user?.name || 'Kullanıcı'} izin talebinde bulundu`;
                time = formatDateTime(activity.startDate);
                description = activity.description;
                icon = <Calendar size={18} className="text-purple-500" />;
              }
              
              return (
                <div key={index} className="py-3 flex items-start">
                  <div className="mr-3 mt-1">{icon}</div>
                  <div>
                    <p className="text-gray-800 font-medium">{title}</p>
                    <p className="text-gray-500 text-sm">{time}</p>
                    {description && <p className="text-gray-600 text-sm mt-1">{description}</p>}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-4">Bugün henüz aktivite yok</p>
        )}
      </div>
    </div>
  );
};

export default Dashboard;