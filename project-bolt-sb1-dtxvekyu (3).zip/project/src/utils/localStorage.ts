import { User, Factory, CheckInOut, OvertimeRequest, LeaveRequest } from '../types';

const KEYS = {
  USERS: 'users',
  FACTORIES: 'factories',
  CHECK_IN_OUT: 'checkInOut',
  OVERTIME_REQUESTS: 'overtimeRequests',
  LEAVE_REQUESTS: 'leaveRequests',
  CURRENT_USER: 'currentUser',
};

// Initialize with admin user if it doesn't exist
const initializeData = () => {
  if (!localStorage.getItem(KEYS.USERS)) {
    const adminUser: User = {
      id: '1',
      name: 'Admin',
      email: 'serkan@2motomasyon.com.tr',
      password: '2mpersonel', // In a real app, this would be hashed
      role: 'admin',
    };
    localStorage.setItem(KEYS.USERS, JSON.stringify([adminUser]));
  }

  if (!localStorage.getItem(KEYS.FACTORIES)) {
    localStorage.setItem(KEYS.FACTORIES, JSON.stringify([]));
  }

  if (!localStorage.getItem(KEYS.CHECK_IN_OUT)) {
    localStorage.setItem(KEYS.CHECK_IN_OUT, JSON.stringify([]));
  }

  if (!localStorage.getItem(KEYS.OVERTIME_REQUESTS)) {
    localStorage.setItem(KEYS.OVERTIME_REQUESTS, JSON.stringify([]));
  }

  if (!localStorage.getItem(KEYS.LEAVE_REQUESTS)) {
    localStorage.setItem(KEYS.LEAVE_REQUESTS, JSON.stringify([]));
  }
};

// User methods
export const getUsers = (): User[] => {
  initializeData();
  return JSON.parse(localStorage.getItem(KEYS.USERS) || '[]');
};

export const getUserById = (id: string): User | undefined => {
  const users = getUsers();
  return users.find(user => user.id === id);
};

export const getUserByNameOrEmail = (nameOrEmail: string): User | undefined => {
  const users = getUsers();
  return users.find(
    user => user.name === nameOrEmail || (user.email && user.email === nameOrEmail)
  );
};

export const addUser = (user: User): void => {
  const users = getUsers();
  users.push(user);
  localStorage.setItem(KEYS.USERS, JSON.stringify(users));
};

export const updateUser = (updatedUser: User): void => {
  const users = getUsers();
  const index = users.findIndex(user => user.id === updatedUser.id);
  if (index !== -1) {
    users[index] = updatedUser;
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
  }
};

export const deleteUser = (id: string): void => {
  const users = getUsers();
  const filteredUsers = users.filter(user => user.id !== id);
  localStorage.setItem(KEYS.USERS, JSON.stringify(filteredUsers));
};

// Factory methods
export const getFactories = (): Factory[] => {
  initializeData();
  return JSON.parse(localStorage.getItem(KEYS.FACTORIES) || '[]');
};

export const getFactoryById = (id: string): Factory | undefined => {
  const factories = getFactories();
  return factories.find(factory => factory.id === id);
};

export const addFactory = (factory: Factory): void => {
  const factories = getFactories();
  factories.push(factory);
  localStorage.setItem(KEYS.FACTORIES, JSON.stringify(factories));
};

export const updateFactory = (updatedFactory: Factory): void => {
  const factories = getFactories();
  const index = factories.findIndex(factory => factory.id === updatedFactory.id);
  if (index !== -1) {
    factories[index] = updatedFactory;
    localStorage.setItem(KEYS.FACTORIES, JSON.stringify(factories));
  }
};

export const deleteFactory = (id: string): void => {
  const factories = getFactories();
  const filteredFactories = factories.filter(factory => factory.id !== id);
  localStorage.setItem(KEYS.FACTORIES, JSON.stringify(filteredFactories));
};

// Check-in/out methods
export const getCheckInOuts = (): CheckInOut[] => {
  initializeData();
  return JSON.parse(localStorage.getItem(KEYS.CHECK_IN_OUT) || '[]');
};

export const getCheckInOutsByUserId = (userId: string): CheckInOut[] => {
  const checkInOuts = getCheckInOuts();
  return checkInOuts.filter(checkInOut => checkInOut.userId === userId);
};

export const addCheckInOut = (checkInOut: CheckInOut): void => {
  const checkInOuts = getCheckInOuts();
  checkInOuts.push(checkInOut);
  localStorage.setItem(KEYS.CHECK_IN_OUT, JSON.stringify(checkInOuts));
};

// Overtime request methods
export const getOvertimeRequests = (): OvertimeRequest[] => {
  initializeData();
  return JSON.parse(localStorage.getItem(KEYS.OVERTIME_REQUESTS) || '[]');
};

export const getOvertimeRequestsByUserId = (userId: string): OvertimeRequest[] => {
  const overtimeRequests = getOvertimeRequests();
  return overtimeRequests.filter(request => request.userId === userId);
};

export const addOvertimeRequest = (request: OvertimeRequest): void => {
  const overtimeRequests = getOvertimeRequests();
  overtimeRequests.push(request);
  localStorage.setItem(KEYS.OVERTIME_REQUESTS, JSON.stringify(overtimeRequests));
};

export const updateOvertimeRequest = (updatedRequest: OvertimeRequest): void => {
  const overtimeRequests = getOvertimeRequests();
  const index = overtimeRequests.findIndex(req => req.id === updatedRequest.id);
  if (index !== -1) {
    overtimeRequests[index] = updatedRequest;
    localStorage.setItem(KEYS.OVERTIME_REQUESTS, JSON.stringify(overtimeRequests));
  }
};

// Leave request methods
export const getLeaveRequests = (): LeaveRequest[] => {
  initializeData();
  return JSON.parse(localStorage.getItem(KEYS.LEAVE_REQUESTS) || '[]');
};

export const getLeaveRequestsByUserId = (userId: string): LeaveRequest[] => {
  const leaveRequests = getLeaveRequests();
  return leaveRequests.filter(request => request.userId === userId);
};

export const addLeaveRequest = (request: LeaveRequest): void => {
  const leaveRequests = getLeaveRequests();
  leaveRequests.push(request);
  localStorage.setItem(KEYS.LEAVE_REQUESTS, JSON.stringify(leaveRequests));
};

export const updateLeaveRequest = (updatedRequest: LeaveRequest): void => {
  const leaveRequests = getLeaveRequests();
  const index = leaveRequests.findIndex(req => req.id === updatedRequest.id);
  if (index !== -1) {
    leaveRequests[index] = updatedRequest;
    localStorage.setItem(KEYS.LEAVE_REQUESTS, JSON.stringify(leaveRequests));
  }
};

// Current user methods
export const setCurrentUser = (user: User | null): void => {
  if (user) {
    localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(user));
  } else {
    localStorage.removeItem(KEYS.CURRENT_USER);
  }
};

export const getCurrentUser = (): User | null => {
  const userJson = localStorage.getItem(KEYS.CURRENT_USER);
  return userJson ? JSON.parse(userJson) : null;
};